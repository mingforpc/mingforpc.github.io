#include <iostream>
#include "com_self_test_HelloNative.h"
using namespace std;

JNIEXPORT void JNICALL Java_com_self_test_HelloNative_helloWorld(JNIEnv *, jobject)
{
	cout << "Hello World" << endl;
}