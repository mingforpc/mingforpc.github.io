package com.self.test;

public class HelloNative {

    private static boolean neverLoaded = true;

    public static void LoadLibrary() {
        if (neverLoaded) {
            System.loadLibrary("libHello");
            neverLoaded = false;

        }
    }

    // public static void LoadLibrary() {
    //
    // String value = System.getProperty("loadedLib");
    // System.out.println(value);
    // if(value == null) {
    // System.loadLibrary("libHello");
    // System.setProperty("loadedLib", "true");
    // }
    // }

    public native void helloWorld();
}